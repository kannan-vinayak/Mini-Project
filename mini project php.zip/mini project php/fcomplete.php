<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
    .bg{
        background-size: 100%;
        background-color: gray;
    }
    .form-container {
        margin-top: 10%;
        margin-left: 15%;
        width: 70%;
        background: #fff;
        padding:20px;
        border-radius:10px ;
        box-shadow: 0px 0px 15px 0px #000;
    }
    </style>
</head>
<body>
<div class="form-container">
    <center>
        <h1>You accepted the Donation.</h1>
    </center>
        </div>
</body>
</html>